class LimiteChequeEspecialError(Exception):
    pass